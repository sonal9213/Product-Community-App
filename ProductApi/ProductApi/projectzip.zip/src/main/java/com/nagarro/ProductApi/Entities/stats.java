package com.nagarro.ProductApi.Entities;

public class stats {
	
	long countProducts;
	long countReviews;
	long countUsers;
	public long getCountProducts() {
		return countProducts;
	}
	public void setCountProducts(long countProducts) {
		this.countProducts = countProducts;
	}
	public long getCountReviews() {
		return countReviews;
	}
	public void setCountReviews(long countReviews) {
		this.countReviews = countReviews;
	}
	public long getCountUsers() {
		return countUsers;
	}
	public void setCountUsers(long countUsers) {
		this.countUsers = countUsers;
	}
	
	

}
